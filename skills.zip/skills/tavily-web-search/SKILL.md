---
name: tavily-web-search
description: Web search throguh Tavily client
---

## Tavily Web Research Tools

All agents have access to **Tavily** — a web research toolkit available via the LiteLLM gateway's MCP endpoint. Tavily provides 5 tools for web search, content extraction, crawling, site mapping, and deep research.

### Quick Reference

```python
from tavily_client import Tavily

tavily = Tavily()  # Reads credentials from settings.json automatically

# Search the web
results = tavily.search("query", max_results=10)

# Extract full content from URLs
pages = tavily.extract(["https://example.com/page"])

# Crawl a website (follow links)
site = tavily.crawl("https://docs.example.com", max_depth=2, limit=20)

# Map a website's URL structure
urls = tavily.map("https://docs.example.com", limit=50)

# Deep multi-source research report
report = tavily.research("Research topic description")
```

### Tool Capabilities

| Tool | What It Does | Speed | Best For |
|------|-------------|-------|----------|
| **search** | Web search with structured results | ~1s | Quick lookups, news, finding URLs |
| **extract** | Extract full content from specific URLs | ~2-5s | Reading docs, articles, specs |
| **crawl** | Crawl a site following links | ~5-15s | Documentation, comprehensive analysis |
| **map** | Discover URL structure of a site | ~2-5s | Finding the right page before extracting |
| **research** | Multi-source deep research report | ~30-60s | Complex topics, comparisons, analysis |

### Search Parameters

| Parameter | Values | Description |
|-----------|--------|-------------|
| `search_depth` | `"basic"`, `"advanced"` | Depth of search |
| `topic` | `"general"`, `"news"`, `"finance"` | Search category |
| `time_range` | `"day"`, `"week"`, `"month"`, `"year"` | Recency filter |
| `include_raw_content` | `True`/`False` | Include cleaned HTML per result |
| `include_domains` | `["site.com"]` | Whitelist domains |
| `exclude_domains` | `["site.com"]` | Blacklist domains |

### Credentials

Tavily reads from `settings.json` (the same file used by `claude-wrapper.sh`) via the `utils/litellm_client` module. **No manual API key setup needed.**

### When to Use Tavily vs Internet Search

| Scenario | Use |
|----------|-----|
| Need structured results with metadata | **Tavily search** |
| Need full page content from a known URL | **Tavily extract** |
| Need to crawl an entire docs site | **Tavily crawl** |
| Quick fact lookup | Either works |
| Need a comprehensive research report | **Tavily research** |

---